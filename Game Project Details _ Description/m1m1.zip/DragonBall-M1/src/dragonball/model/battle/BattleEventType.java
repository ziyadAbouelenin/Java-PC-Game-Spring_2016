package dragonball.model.battle;

public enum BattleEventType {
STARTED,ENDED,NEW_TURN,ATTACK,BLOCK,USE
}
