package dragonball.model.battle;

public interface BattleOpponent {
public void onAttackerTurn();
public void onDefenderTurn();
}
