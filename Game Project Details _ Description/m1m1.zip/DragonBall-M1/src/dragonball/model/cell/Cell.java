package dragonball.model.cell;

public abstract class Cell {
	private CellListener listener;
	public CellListener getListener() {
		return listener;
	}
	public abstract String toString();
	
	public abstract void onStep();
}
