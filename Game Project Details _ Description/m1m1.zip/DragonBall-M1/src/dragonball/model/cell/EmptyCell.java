package dragonball.model.cell;

public class EmptyCell extends Cell {
	@Override
	public String toString() {
		return "[ ]";
	}

	@Override
	public void onStep() {
    
	}
}
