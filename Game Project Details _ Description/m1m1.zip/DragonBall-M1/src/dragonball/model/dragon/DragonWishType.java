package dragonball.model.dragon;

public enum DragonWishType {
SENZU_BEANS,ABILITY_POINTS,SUPER_ATTACK,ULTIMATE_ATTACK
}
