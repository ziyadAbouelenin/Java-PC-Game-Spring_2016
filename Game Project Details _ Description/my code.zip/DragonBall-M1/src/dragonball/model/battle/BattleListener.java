package dragonball.model.battle;

import java.util.EventListener;

public interface BattleListener  {
	public void onBattleEvent(BattleEvent e);

}
