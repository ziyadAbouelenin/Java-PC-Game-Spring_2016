package dragonball.model.cell;

public class CollectibleCell extends Cell {
	private Collectible collectible;

	public CollectibleCell(Collectible collectible) {
		this.collectible = collectible;
	}

	public Collectible getCollectible() {
		return collectible;
	}
public void onStep(){
	if(this.getListener()!=null)
		this.getListener().onCollectibleFound(collectible);
		
}
	@Override
	public String toString() {
		switch (collectible) {
		case SENZU_BEAN:
			return "[s]";
		case DRAGON_BALL:
			return "[d]";
		}

		return "[" + Character.toLowerCase(collectible.name().charAt(0)) + "]";
	}
}
