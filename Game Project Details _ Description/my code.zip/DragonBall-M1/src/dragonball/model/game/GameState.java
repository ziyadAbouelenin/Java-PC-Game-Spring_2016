package dragonball.model.game;

public enum GameState {
WORLD,BATTLE,DRAGON
}
